<?php namespace estoque\Events;

abstract class Event {

	//

}

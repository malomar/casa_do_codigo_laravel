<?php

return [
	"required" => "The :attribute field can not be empty."
];